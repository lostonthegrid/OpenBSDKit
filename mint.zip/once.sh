echo "pick no x11 and java 17"
pkg_add emacs jdk
pkg_add p5-www-mechanize-gzip
cd container
cp -r -f * /usr/local/
cd /usr/local/bin
chmod 775 *
sh deploy

